<?php
include '../includes/header.php';
include '../config/database.php';

$filter = $_GET['filter'] ?? 'hari_ini';
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

switch ($filter) {
    case 'hari_ini':
        $where = "DATE(t.created_at) = CURDATE()";
        break;
    case 'minggu_ini':
        $where = "YEARWEEK(t.created_at) = YEARWEEK(CURDATE())";
        break;
    case 'bulan_ini':
        $where = "MONTH(t.created_at) = MONTH(CURDATE()) AND YEAR(t.created_at) = YEAR(CURDATE())";
        break;
    case 'custom':
        $where = "DATE(t.created_at) BETWEEN '$start_date' AND '$end_date'";
        break;
    default:
        $where = "DATE(t.created_at) = CURDATE()";
}

$transaksi = fetch_all("SELECT t.*, u.nama_lengkap as petugas 
                        FROM transaksi t 
                        LEFT JOIN users u ON t.petugas_id = u.id 
                        WHERE $where 
                        ORDER BY t.created_at DESC");

$summary = fetch_one("SELECT COUNT(*) as total_transaksi, SUM(total_biaya) as total_pendapatan 
                      FROM transaksi WHERE $where");
?>

<div class="space-y-6">
    <h1 class="text-2xl font-bold">📊 Laporan Transaksi</h1>
    
    <!-- Filter -->
    <div class="bg-white p-4 rounded-lg shadow-md">
        <form method="GET" class="flex flex-wrap gap-3 items-end">
            <div>
                <label class="block text-sm mb-1">Filter</label>
                <select name="filter" class="px-3 py-2 border rounded">
                    <option value="hari_ini" <?php echo $filter == 'hari_ini' ? 'selected' : ''; ?>>Hari Ini</option>
                    <option value="minggu_ini" <?php echo $filter == 'minggu_ini' ? 'selected' : ''; ?>>Minggu Ini</option>
                    <option value="bulan_ini" <?php echo $filter == 'bulan_ini' ? 'selected' : ''; ?>>Bulan Ini</option>
                    <option value="custom" <?php echo $filter == 'custom' ? 'selected' : ''; ?>>Custom</option>
                </select>
            </div>
            <div id="date_range" class="<?php echo $filter != 'custom' ? 'hidden' : ''; ?> flex gap-3">
                <div>
                    <label class="block text-sm mb-1">Dari</label>
                    <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="px-3 py-2 border rounded">
                </div>
                <div>
                    <label class="block text-sm mb-1">Sampai</label>
                    <input type="date" name="end_date" value="<?php echo $end_date; ?>" class="px-3 py-2 border rounded">
                </div>
            </div>
            <div>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Tampilkan
                </button>
            </div>
        </form>
    </div>
    
    <!-- Summary -->
    <div class="grid grid-cols-2 gap-4">
        <div class="bg-green-100 p-4 rounded-lg">
            <div class="text-sm text-green-700">Total Transaksi</div>
            <div class="text-2xl font-bold"><?php echo $summary['total_transaksi'] ?? 0; ?></div>
        </div>
        <div class="bg-blue-100 p-4 rounded-lg">
            <div class="text-sm text-blue-700">Total Pendapatan</div>
            <div class="text-2xl font-bold">Rp <?php echo number_format($summary['total_pendapatan'] ?? 0, 0, ',', '.'); ?></div>
        </div>
    </div>
    
    <!-- Tabel Transaksi -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">ID</th>
                        <th class="p-2 text-left">Plat Nomor</th>
                        <th class="p-2 text-left">Waktu Masuk</th>
                        <th class="p-2 text-left">Waktu Keluar</th>
                        <th class="p-2 text-left">Durasi</th>
                        <th class="p-2 text-left">Tarif/Jam</th>
                        <th class="p-2 text-left">Total</th>
                        <th class="p-2 text-left">Petugas</th>
                        <th class="p-2 text-left">Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transaksi as $t): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $t['id']; ?></td>
                        <td class="p-2 font-bold"><?php echo $t['no_plat']; ?></td>
                        <td class="p-2"><?php echo date('d/m/Y H:i', strtotime($t['waktu_masuk'])); ?></td>
                        <td class="p-2"><?php echo date('d/m/Y H:i', strtotime($t['waktu_keluar'])); ?></td>
                        <td class="p-2"><?php echo $t['durasi']; ?> jam</td>
                        <td class="p-2">Rp <?php echo number_format($t['tarif_per_jam'], 0, ',', '.'); ?></td>
                        <td class="p-2 font-bold">Rp <?php echo number_format($t['total_biaya'], 0, ',', '.'); ?></td>
                        <td class="p-2"><?php echo $t['petugas'] ?? '-'; ?></td>
                        <td class="p-2"><?php echo date('d/m/Y', strtotime($t['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($transaksi)): ?>
                    <tr><td colspan="9" class="p-2 text-center text-gray-500">Tidak ada data transaksi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.querySelector('select[name="filter"]').addEventListener('change', function() {
    const dateRange = document.getElementById('date_range');
    if (this.value === 'custom') {
        dateRange.classList.remove('hidden');
    } else {
        dateRange.classList.add('hidden');
    }
});
</script>

<?php include '../includes/footer.php'; ?>