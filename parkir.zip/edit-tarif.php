<?php
include '../includes/header.php';
include '../config/database.php';

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];
$tarif = fetch_one("SELECT * FROM tarif WHERE id = $id");

if (!$tarif) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jenis = mysqli_real_escape_string($koneksi, $_POST['jenis_kendaraan']);
    $tarif_per_jam = (int)$_POST['tarif_per_jam'];
    
    $sql = "UPDATE tarif SET jenis_kendaraan='$jenis', tarif_per_jam=$tarif_per_jam WHERE id=$id";
    if (query($sql)) {
        include '../includes/auth.php';
        log_aktivitas($_SESSION['user_id'], "Edit tarif: $jenis");
        header("Location: index.php");
        exit();
    } else {
        $error = "Gagal mengupdate tarif!";
    }
}
?>

<div class="max-w-lg mx-auto">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold">Edit Tarif</h1>
        <a href="index.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Kembali</a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Jenis Kendaraan</label>
                <input type="text" name="jenis_kendaraan" value="<?php echo $tarif['jenis_kendaraan']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Tarif Per Jam (Rp)</label>
                <input type="number" name="tarif_per_jam" value="<?php echo $tarif['tarif_per_jam']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>