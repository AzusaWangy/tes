<?php
include '../includes/header.php';
include '../config/database.php';

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$tarif = fetch_all("SELECT * FROM tarif ORDER BY id");
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-bold">💰 Kelola Tarif Parkir</h1>
        <a href="create.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">+ Tambah Tarif</a>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">ID</th>
                        <th class="p-2 text-left">Jenis Kendaraan</th>
                        <th class="p-2 text-left">Tarif Per Jam</th>
                        <th class="p-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tarif as $t): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $t['id']; ?></td>
                        <td class="p-2 font-bold"><?php echo $t['jenis_kendaraan']; ?></td>
                        <td class="p-2">Rp <?php echo number_format($t['tarif_per_jam'], 0, ',', '.'); ?></td>
                        <td class="p-2">
                            <a href="edit.php?id=<?php echo $t['id']; ?>" class="text-blue-500 hover:underline">Edit</a>
                            | <a href="delete.php?id=<?php echo $t['id']; ?>" onclick="return confirm('Yakin hapus?')" class="text-red-500 hover:underline">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>