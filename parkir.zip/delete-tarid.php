<?php
include '../config/database.php';
session_start();

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];
$tarif = fetch_one("SELECT jenis_kendaraan FROM tarif WHERE id = $id");

if ($tarif) {
    include '../includes/auth.php';
    log_aktivitas($_SESSION['user_id'], "Hapus tarif: {$tarif['jenis_kendaraan']}");
    query("DELETE FROM tarif WHERE id = $id");
}

header("Location: index.php");
exit();
?>