<?php
include '../config/database.php';
session_start();

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];
$area = fetch_one("SELECT kode_area FROM area_parkir WHERE id = $id");

if ($area) {
    include '../includes/auth.php';
    log_aktivitas($_SESSION['user_id'], "Hapus area parkir: {$area['kode_area']}");
    query("DELETE FROM area_parkir WHERE id = $id");
}

header("Location: index.php");
exit();
?>