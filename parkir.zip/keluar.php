<?php
include '../includes/header.php';
include '../config/database.php';

$error = '';
$struk_data = null;

// Proses keluar
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['no_plat'])) {
    $no_plat = mysqli_real_escape_string($koneksi, $_POST['no_plat']);
    
    $kendaraan = fetch_one("SELECT k.*, a.id as area_id FROM kendaraan k 
                            LEFT JOIN area_parkir a ON k.area_id = a.id 
                            WHERE k.no_plat = '$no_plat' AND k.status = 'parkir'");
    
    if ($kendaraan) {
        $waktu_keluar = date('Y-m-d H:i:s');
        $waktu_masuk = $kendaraan['waktu_masuk'];
        $durasi = ceil((strtotime($waktu_keluar) - strtotime($waktu_masuk)) / 3600);
        if ($durasi < 1) $durasi = 1;
        
        $tarif_data = fetch_one("SELECT tarif_per_jam FROM tarif WHERE jenis_kendaraan = '{$kendaraan['jenis_kendaraan']}'");
        $tarif_per_jam = $tarif_data['tarif_per_jam'];
        $total_biaya = $durasi * $tarif_per_jam;
        
        // Update kendaraan
        query("UPDATE kendaraan SET waktu_keluar = '$waktu_keluar', durasi = $durasi, 
                biaya = $total_biaya, status = 'keluar' WHERE id = {$kendaraan['id']}");
        
        // Update kapasitas area
        if ($kendaraan['area_id']) {
            query("UPDATE area_parkir SET terisi = terisi - 1 WHERE id = {$kendaraan['area_id']}");
        }
        
        // Simpan transaksi
        query("INSERT INTO transaksi (kendaraan_id, no_plat, waktu_masuk, waktu_keluar, durasi, 
                tarif_per_jam, total_biaya, petugas_id) 
                VALUES ({$kendaraan['id']}, '$no_plat', '$waktu_masuk', '$waktu_keluar', 
                $durasi, $tarif_per_jam, $total_biaya, {$_SESSION['user_id']})");
        
        include '../includes/auth.php';
        log_aktivitas($_SESSION['user_id'], "Kendaraan keluar: $no_plat - Biaya: Rp $total_biaya");
        
        $struk_data = [
            'no_plat' => $no_plat,
            'jenis' => $kendaraan['jenis_kendaraan'],
            'waktu_masuk' => $waktu_masuk,
            'waktu_keluar' => $waktu_keluar,
            'durasi' => $durasi,
            'tarif_per_jam' => $tarif_per_jam,
            'total_biaya' => $total_biaya
        ];
    } else {
        $error = "Kendaraan dengan plat $no_plat tidak ditemukan atau sudah keluar!";
    }
}

$parkir_list = fetch_all("SELECT no_plat, jenis_kendaraan, waktu_masuk FROM kendaraan WHERE status = 'parkir' ORDER BY waktu_masuk");
?>

<div class="space-y-6">
    <h1 class="text-2xl font-bold">🚗 Kendaraan Keluar</h1>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if ($struk_data): ?>
    <!-- Struk Parkir -->
    <div class="bg-white p-6 rounded-lg shadow-md border-2 border-gray-300" id="struk">
        <div class="text-center mb-4">
            <h2 class="text-xl font-bold">STRUK PARKIR</h2>
            <p class="text-gray-500"><?php echo date('d/m/Y H:i:s'); ?></p>
        </div>
        <div class="space-y-2">
            <div class="flex justify-between"><span>Nomor Plat:</span><span class="font-bold"><?php echo $struk_data['no_plat']; ?></span></div>
            <div class="flex justify-between"><span>Jenis Kendaraan:</span><span><?php echo $struk_data['jenis']; ?></span></div>
            <div class="flex justify-between"><span>Waktu Masuk:</span><span><?php echo date('d/m/Y H:i', strtotime($struk_data['waktu_masuk'])); ?></span></div>
            <div class="flex justify-between"><span>Waktu Keluar:</span><span><?php echo date('d/m/Y H:i', strtotime($struk_data['waktu_keluar'])); ?></span></div>
            <div class="flex justify-between"><span>Durasi:</span><span><?php echo $struk_data['durasi']; ?> jam</span></div>
            <div class="flex justify-between"><span>Tarif/Jam:</span><span>Rp <?php echo number_format($struk_data['tarif_per_jam'], 0, ',', '.'); ?></span></div>
            <div class="border-t pt-2 mt-2">
                <div class="flex justify-between font-bold text-lg">
                    <span>TOTAL BAYAR:</span>
                    <span>Rp <?php echo number_format($struk_data['total_biaya'], 0, ',', '.'); ?></span>
                </div>
            </div>
        </div>
        <div class="text-center mt-4 text-gray-400 text-sm">
            Terima kasih sudah menggunakan layanan parkir kami
        </div>
    </div>
    
    <div class="flex gap-3">
        <button onclick="window.print()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
            🖨️ Cetak Struk
        </button>
        <a href="keluar.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
            Kembali
        </a>
    </div>
    <?php else: ?>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-gray-700 mb-2">Masukkan Nomor Plat</label>
                <div class="flex gap-3">
                    <input type="text" name="no_plat" list="plat_list" required 
                        class="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
                        placeholder="Contoh: B 1234 XYZ">
                    <button type="submit" class="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600">
                        Proses Keluar
                    </button>
                </div>
                <datalist id="plat_list">
                    <?php foreach ($parkir_list as $p): ?>
                    <option value="<?php echo $p['no_plat']; ?>">
                    <?php endforeach; ?>
                </datalist>
            </div>
        </form>
    </div>
    
    <!-- Daftar Kendaraan Parkir -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4">Kendaraan Sedang Parkir</h2>
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">Plat Nomor</th>
                        <th class="p-2 text-left">Jenis</th>
                        <th class="p-2 text-left">Waktu Masuk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($parkir_list as $k): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $k['no_plat']; ?></td>
                        <td class="p-2"><?php echo $k['jenis_kendaraan']; ?></td>
                        <td class="p-2"><?php echo date('d/m/Y H:i', strtotime($k['waktu_masuk'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>