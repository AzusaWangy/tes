<?php
session_start();
include 'config/database.php';
include 'includes/auth.php';

if (isset($_SESSION['user_id'])) {
    log_aktivitas($_SESSION['user_id'], "Logout");
}

session_destroy();
header("Location: login.php");
exit();
?>