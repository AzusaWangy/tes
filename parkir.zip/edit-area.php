<?php
include '../includes/header.php';
include '../config/database.php';

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];
$area = fetch_one("SELECT * FROM area_parkir WHERE id = $id");

if (!$area) {
    header("Location: index.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode = strtoupper(mysqli_real_escape_string($koneksi, $_POST['kode_area']));
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_area']);
    $kapasitas = (int)$_POST['kapasitas'];
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);
    
    $sql = "UPDATE area_parkir SET kode_area='$kode', nama_area='$nama', kapasitas=$kapasitas, status='$status' WHERE id=$id";
    if (query($sql)) {
        include '../includes/auth.php';
        log_aktivitas($_SESSION['user_id'], "Edit area parkir: $kode");
        header("Location: index.php");
        exit();
    } else {
        $error = "Gagal mengupdate area!";
    }
}
?>

<div class="max-w-lg mx-auto">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold">Edit Area Parkir</h1>
        <a href="index.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Kembali</a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Kode Area</label>
                <input type="text" name="kode_area" value="<?php echo $area['kode_area']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Nama Area</label>
                <input type="text" name="nama_area" value="<?php echo $area['nama_area']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Kapasitas</label>
                <input type="number" name="kapasitas" value="<?php echo $area['kapasitas']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Status</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded">
                    <option value="aktif" <?php echo $area['status'] == 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="nonaktif" <?php echo $area['status'] == 'nonaktif' ? 'selected' : ''; ?>>Nonaktif</option>
                </select>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>