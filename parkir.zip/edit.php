<?php
include '../includes/header.php';
include '../config/database.php';

if ($_SESSION['level'] != 'admin') {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];
$user = fetch_one("SELECT * FROM users WHERE id = $id");

if (!$user) {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap']);
    $level = mysqli_real_escape_string($koneksi, $_POST['level']);
    $password = $_POST['password'];
    
    if (!empty($password)) {
        $password_md5 = md5($password);
        $sql = "UPDATE users SET username='$username', password='$password_md5', nama_lengkap='$nama_lengkap', level='$level' WHERE id=$id";
    } else {
        $sql = "UPDATE users SET username='$username', nama_lengkap='$nama_lengkap', level='$level' WHERE id=$id";
    }
    
    if (query($sql)) {
        include '../includes/auth.php';
        log_aktivitas($_SESSION['user_id'], "Edit user: $username");
        $success = "User berhasil diupdate!";
        echo "<script>setTimeout(() => window.location.href='index.php', 1000);</script>";
    } else {
        $error = "Gagal mengupdate user!";
    }
}
?>

<div class="max-w-lg mx-auto">
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold">Edit User</h1>
        <a href="index.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Kembali</a>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST">
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Username</label>
                <input type="text" name="username" value="<?php echo $user['username']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Password (kosongkan jika tidak diubah)</label>
                <input type="password" name="password" class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" value="<?php echo $user['nama_lengkap']; ?>" required class="w-full px-3 py-2 border border-gray-300 rounded">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 mb-2">Level</label>
                <select name="level" required class="w-full px-3 py-2 border border-gray-300 rounded">
                    <option value="admin" <?php echo $user['level'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="petugas" <?php echo $user['level'] == 'petugas' ? 'selected' : ''; ?>>Petugas</option>
                    <option value="owner" <?php echo $user['level'] == 'owner' ? 'selected' : ''; ?>>Owner</option>
                </select>
            </div>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>