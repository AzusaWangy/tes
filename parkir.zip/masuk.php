<?php
include '../includes/header.php';
include '../config/database.php';

$area_list = fetch_all("SELECT * FROM area_parkir WHERE status = 'aktif' AND terisi < kapasitas");
$tarif_list = fetch_all("SELECT * FROM tarif");

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no_plat = strtoupper(mysqli_real_escape_string($koneksi, $_POST['no_plat']));
    $jenis_kendaraan = mysqli_real_escape_string($koneksi, $_POST['jenis_kendaraan']);
    $area_id = (int)$_POST['area_id'];
    $waktu_masuk = date('Y-m-d H:i:s');
    
    // Cek apakah kendaraan sudah parkir
    $cek = fetch_one("SELECT id FROM kendaraan WHERE no_plat = '$no_plat' AND status = 'parkir'");
    if ($cek) {
        $error = "Kendaraan dengan plat $no_plat sedang parkir!";
    } else {
        $sql = "INSERT INTO kendaraan (no_plat, jenis_kendaraan, area_id, waktu_masuk, status) 
                VALUES ('$no_plat', '$jenis_kendaraan', $area_id, '$waktu_masuk', 'parkir')";
        
        if (query($sql)) {
            // Update kapasitas area
            query("UPDATE area_parkir SET terisi = terisi + 1 WHERE id = $area_id");
            
            include '../includes/auth.php';
            log_aktivitas($_SESSION['user_id'], "Kendaraan masuk: $no_plat");
            
            $success = "Kendaraan $no_plat berhasil masuk parkir!";
        } else {
            $error = "Gagal memasukkan kendaraan!";
        }
    }
}
?>

<div class="space-y-6">
    <h1 class="text-2xl font-bold">🚘 Kendaraan Masuk Parkir</h1>
    
    <?php if ($success): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-gray-700 mb-2">Nomor Plat Kendaraan</label>
                <input type="text" name="no_plat" required 
                    class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
                    placeholder="Contoh: B 1234 XYZ">
            </div>
            
            <div>
                <label class="block text-gray-700 mb-2">Jenis Kendaraan</label>
                <select name="jenis_kendaraan" required class="w-full px-3 py-2 border border-gray-300 rounded">
                    <option value="">Pilih Jenis</option>
                    <?php foreach ($tarif_list as $tarif): ?>
                    <option value="<?php echo $tarif['jenis_kendaraan']; ?>">
                        <?php echo $tarif['jenis_kendaraan']; ?> - Rp <?php echo number_format($tarif['tarif_per_jam'], 0, ',', '.'); ?>/jam
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-gray-700 mb-2">Area Parkir</label>
                <select name="area_id" required class="w-full px-3 py-2 border border-gray-300 rounded">
                    <option value="">Pilih Area</option>
                    <?php foreach ($area_list as $area): ?>
                    <option value="<?php echo $area['id']; ?>">
                        <?php echo $area['kode_area']; ?> - <?php echo $area['nama_area']; ?> 
                        (Tersedia: <?php echo $area['kapasitas'] - $area['terisi']; ?> slot)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" class="bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600">
                Simpan Masuk Parkir
            </button>
        </form>
    </div>
    
    <!-- Daftar Kendaraan Parkir -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4">Kendaraan Sedang Parkir</h2>
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">Plat Nomor</th>
                        <th class="p-2 text-left">Jenis</th>
                        <th class="p-2 text-left">Area</th>
                        <th class="p-2 text-left">Waktu Masuk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $parkir_list = fetch_all("SELECT k.*, a.kode_area FROM kendaraan k 
                                              LEFT JOIN area_parkir a ON k.area_id = a.id 
                                              WHERE k.status = 'parkir' ORDER BY k.waktu_masuk DESC LIMIT 20");
                    foreach ($parkir_list as $k): 
                    ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $k['no_plat']; ?></td>
                        <td class="p-2"><?php echo $k['jenis_kendaraan']; ?></td>
                        <td class="p-2"><?php echo $k['kode_area']; ?></td>
                        <td class="p-2"><?php echo date('d/m/Y H:i', strtotime($k['waktu_masuk'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($parkir_list)): ?>
                    <tr><td colspan="4" class="p-2 text-center text-gray-500">Tidak ada kendaraan parkir</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>