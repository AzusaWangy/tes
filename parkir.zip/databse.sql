-- Database: db_parkir

CREATE DATABASE IF NOT EXISTS db_parkir;
USE db_parkir;

-- Tabel Users (3 level: admin, petugas, owner)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    level ENUM('admin', 'petugas', 'owner') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Tarif Parkir
CREATE TABLE tarif (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jenis_kendaraan VARCHAR(50) NOT NULL,
    tarif_per_jam DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Area Parkir
CREATE TABLE area_parkir (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_area VARCHAR(10) NOT NULL,
    nama_area VARCHAR(50) NOT NULL,
    kapasitas INT NOT NULL,
    terisi INT DEFAULT 0,
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Kendaraan (Parkir Masuk)
CREATE TABLE kendaraan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    no_plat VARCHAR(20) NOT NULL,
    jenis_kendaraan VARCHAR(50) NOT NULL,
    area_id INT,
    waktu_masuk DATETIME NOT NULL,
    waktu_keluar DATETIME NULL,
    durasi INT NULL,
    biaya DECIMAL(10,2) NULL,
    status ENUM('parkir', 'keluar') DEFAULT 'parkir',
    FOREIGN KEY (area_id) REFERENCES area_parkir(id) ON DELETE SET NULL
);

-- Tabel Transaksi
CREATE TABLE transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kendaraan_id INT,
    no_plat VARCHAR(20) NOT NULL,
    waktu_masuk DATETIME NOT NULL,
    waktu_keluar DATETIME NOT NULL,
    durasi INT NOT NULL,
    tarif_per_jam DECIMAL(10,2) NOT NULL,
    total_biaya DECIMAL(10,2) NOT NULL,
    petugas_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kendaraan_id) REFERENCES kendaraan(id),
    FOREIGN KEY (petugas_id) REFERENCES users(id)
);

-- Tabel Log Aktivitas
CREATE TABLE log_aktivitas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    aktivitas VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert Data Awal
INSERT INTO users (username, password, nama_lengkap, level) VALUES
('admin', MD5('admin123'), 'Administrator', 'admin'),
('petugas1', MD5('petugas123'), 'Petugas Satu', 'petugas'),
('owner', MD5('owner123'), 'Pemilik Parkir', 'owner');

INSERT INTO tarif (jenis_kendaraan, tarif_per_jam) VALUES
('Motor', 2000),
('Mobil', 5000),
('Truk', 10000);

INSERT INTO area_parkir (kode_area, nama_area, kapasitas, terisi) VALUES
('A1', 'Area Motor Timur', 50, 0),
('A2', 'Area Motor Barat', 50, 0),
('B1', 'Area Mobil Utara', 30, 0),
('B2', 'Area Mobil Selatan', 30, 0),
('C1', 'Area Truk Khusus', 10, 0);