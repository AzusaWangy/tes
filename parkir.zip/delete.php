<?php
include '../config/database.php';
session_start();

if ($_SESSION['level'] != 'admin') {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$id = (int)$_GET['id'];

if ($id != $_SESSION['user_id']) {
    $user = fetch_one("SELECT username FROM users WHERE id = $id");
    if ($user) {
        include '../includes/auth.php';
        log_aktivitas($_SESSION['user_id'], "Hapus user: {$user['username']}");
        query("DELETE FROM users WHERE id = $id");
    }
}

header("Location: index.php");
exit();
?>