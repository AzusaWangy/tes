<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'db_parkir';

$koneksi = mysqli_connect($host, $user, $password, $dbname);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Fungsi query helper
function query($sql) {
    global $koneksi;
    return mysqli_query($koneksi, $sql);
}

function fetch_all($sql) {
    global $koneksi;
    $result = mysqli_query($koneksi, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    return $data;
}

function fetch_one($sql) {
    global $koneksi;
    $result = mysqli_query($koneksi, $sql);
    return mysqli_fetch_assoc($result);
}

function insert_id() {
    global $koneksi;
    return mysqli_insert_id($koneksi);
}
?>