<?php
include '../includes/header.php';
include '../config/database.php';

if (!in_array($_SESSION['level'], ['admin', 'petugas'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$area = fetch_all("SELECT * FROM area_parkir ORDER BY id");
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-bold">📍 Kelola Area Parkir</h1>
        <a href="create.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">+ Tambah Area</a>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">ID</th>
                        <th class="p-2 text-left">Kode Area</th>
                        <th class="p-2 text-left">Nama Area</th>
                        <th class="p-2 text-left">Kapasitas</th>
                        <th class="p-2 text-left">Terisi</th>
                        <th class="p-2 text-left">Status</th>
                        <th class="p-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($area as $a): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $a['id']; ?></td>
                        <td class="p-2 font-bold"><?php echo $a['kode_area']; ?></td>
                        <td class="p-2"><?php echo $a['nama_area']; ?></td>
                        <td class="p-2"><?php echo $a['kapasitas']; ?></td>
                        <td class="p-2">
                            <span class="px-2 py-1 rounded text-sm <?php echo $a['terisi'] >= $a['kapasitas'] ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'; ?>">
                                <?php echo $a['terisi']; ?> / <?php echo $a['kapasitas']; ?>
                            </span>
                        </td>
                        <td class="p-2">
                            <span class="px-2 py-1 rounded text-sm <?php echo $a['status'] == 'aktif' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'; ?>">
                                <?php echo $a['status']; ?>
                            </span>
                        </td>
                        <td class="p-2">
                            <a href="edit.php?id=<?php echo $a['id']; ?>" class="text-blue-500 hover:underline">Edit</a>
                            | <a href="delete.php?id=<?php echo $a['id']; ?>" onclick="return confirm('Yakin hapus?')" class="text-red-500 hover:underline">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>