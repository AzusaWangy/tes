<?php
include '../includes/header.php';
include '../config/database.php';

// Hanya admin yang bisa akses
if ($_SESSION['level'] != 'admin') {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$users = fetch_all("SELECT * FROM users ORDER BY id");
?>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h1 class="text-2xl font-bold">👥 Kelola User</h1>
        <a href="create.php" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
            + Tambah User
        </a>
    </div>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">ID</th>
                        <th class="p-2 text-left">Username</th>
                        <th class="p-2 text-left">Nama Lengkap</th>
                        <th class="p-2 text-left">Level</th>
                        <th class="p-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo $user['id']; ?></td>
                        <td class="p-2"><?php echo $user['username']; ?></td>
                        <td class="p-2"><?php echo $user['nama_lengkap']; ?></td>
                        <td class="p-2">
                            <span class="px-2 py-1 rounded text-sm <?php 
                                echo $user['level'] == 'admin' ? 'bg-red-100 text-red-700' : 
                                    ($user['level'] == 'owner' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'); 
                            ?>">
                                <?php echo $user['level']; ?>
                            </span>
                        </td>
                        <td class="p-2">
                            <a href="edit.php?id=<?php echo $user['id']; ?>" class="text-blue-500 hover:underline">Edit</a>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            | <a href="delete.php?id=<?php echo $user['id']; ?>" onclick="return confirm('Yakin hapus?')" class="text-red-500 hover:underline">Hapus</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>