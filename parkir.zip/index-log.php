<?php
include '../includes/header.php';
include '../config/database.php';

// Hanya admin & owner
if (!in_array($_SESSION['level'], ['admin', 'owner'])) {
    header("Location: ../dashboard.php?error=akses_ditolak");
    exit();
}

$logs = fetch_all("SELECT l.*, u.nama_lengkap, u.username 
                   FROM log_aktivitas l 
                   LEFT JOIN users u ON l.user_id = u.id 
                   ORDER BY l.created_at DESC 
                   LIMIT 100");
?>

<div class="space-y-6">
    <h1 class="text-2xl font-bold">📜 Log Aktivitas</h1>
    
    <div class="bg-white p-6 rounded-lg shadow-md">
        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="p-2 text-left">Waktu</th>
                        <th class="p-2 text-left">User</th>
                        <th class="p-2 text-left">Aktivitas</th>
                        <th class="p-2 text-left">IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo date('d/m/Y H:i:s', strtotime($log['created_at'])); ?></td>
                        <td class="p-2"><?php echo $log['nama_lengkap'] ?? 'System'; ?> (<?php echo $log['username'] ?? '-'; ?>)</td>
                        <td class="p-2"><?php echo $log['aktivitas']; ?></td>
                        <td class="p-2"><?php echo $log['ip_address']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>