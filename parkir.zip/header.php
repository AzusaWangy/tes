<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Parkir</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
</head>
<body class="bg-gray-100">
    <nav class="bg-blue-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <div>
                <a href="dashboard.php" class="text-xl font-bold">🚗 Aplikasi Parkir</a>
                <span class="ml-4 text-sm">(<?php echo $_SESSION['level']; ?>)</span>
            </div>
            <div class="flex items-center gap-4">
                <span>Halo, <?php echo $_SESSION['nama_lengkap']; ?></span>
                <a href="logout.php" class="bg-red-500 px-4 py-2 rounded hover:bg-red-600">Logout</a>
            </div>
        </div>
    </nav>
    
    <?php if ($_SESSION['level'] == 'admin' || $_SESSION['level'] == 'petugas' || $_SESSION['level'] == 'owner'): ?>
    <nav class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-2">
            <ul class="flex gap-4 text-gray-700">
                <li><a href="dashboard.php" class="hover:text-blue-600">🏠 Dashboard</a></li>
                
                <?php if ($_SESSION['level'] == 'admin'): ?>
                <li><a href="user/index.php" class="hover:text-blue-600">👥 Kelola User</a></li>
                <?php endif; ?>
                
                <?php if ($_SESSION['level'] == 'admin' || $_SESSION['level'] == 'petugas'): ?>
                <li><a href="tarif/index.php" class="hover:text-blue-600">💰 Tarif Parkir</a></li>
                <li><a href="area/index.php" class="hover:text-blue-600">📍 Area Parkir</a></li>
                <li><a href="kendaraan/masuk.php" class="hover:text-blue-600">🚘 Kendaraan Masuk</a></li>
                <li><a href="kendaraan/keluar.php" class="hover:text-blue-600">🚗 Kendaraan Keluar</a></li>
                <li><a href="transaksi/laporan.php" class="hover:text-blue-600">📊 Laporan Transaksi</a></li>
                <?php endif; ?>
                
                <?php if ($_SESSION['level'] == 'admin' || $_SESSION['level'] == 'owner'): ?>
                <li><a href="log_aktivitas/index.php" class="hover:text-blue-600">📜 Log Aktivitas</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <?php endif; ?>
    
    <div class="container mx-auto px-4 py-6">