<?php
function log_aktivitas($user_id, $aktivitas) {
    global $koneksi;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $sql = "INSERT INTO log_aktivitas (user_id, aktivitas, ip_address) VALUES ($user_id, '$aktivitas', '$ip')";
    query($sql);
}

function cek_akses($allowed_levels = []) {
    if (!in_array($_SESSION['level'], $allowed_levels)) {
        header("Location: dashboard.php?error=akses_ditolak");
        exit();
    }
}
?>