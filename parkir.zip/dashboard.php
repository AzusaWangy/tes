<?php
include 'includes/header.php';
include 'config/database.php';

// Statistik
$total_kendaraan_parkir = fetch_one("SELECT COUNT(*) as total FROM kendaraan WHERE status = 'parkir'")['total'];
$total_transaksi_hari_ini = fetch_one("SELECT COUNT(*) as total, SUM(total_biaya) as pendapatan FROM transaksi WHERE DATE(created_at) = CURDATE()");
$total_area = fetch_one("SELECT SUM(kapasitas) as kapasitas, SUM(terisi) as terisi FROM area_parkir WHERE status = 'aktif'");
?>

<div class="space-y-6">
    <h1 class="text-2xl font-bold">Dashboard Parkir</h1>
    
    <!-- Statistik Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-500">
            <div class="text-gray-500 text-sm">Kendaraan Parkir</div>
            <div class="text-3xl font-bold"><?php echo $total_kendaraan_parkir; ?></div>
            <div class="text-sm text-gray-400">Sedang parkir</div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
            <div class="text-gray-500 text-sm">Transaksi Hari Ini</div>
            <div class="text-3xl font-bold"><?php echo $total_transaksi_hari_ini['total'] ?? 0; ?></div>
            <div class="text-sm text-gray-400">Transaksi</div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md border-l-4 border-yellow-500">
            <div class="text-gray-500 text-sm">Pendapatan Hari Ini</div>
            <div class="text-3xl font-bold">Rp <?php echo number_format($total_transaksi_hari_ini['pendapatan'] ?? 0, 0, ',', '.'); ?></div>
            <div class="text-sm text-gray-400">Total biaya</div>
        </div>
        
        <div class="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-500">
            <div class="text-gray-500 text-sm">Kapasitas Parkir</div>
            <div class="text-3xl font-bold"><?php echo ($total_area['terisi'] ?? 0) . '/' . ($total_area['kapasitas'] ?? 0); ?></div>
            <div class="text-sm text-gray-400">Terisi / Total</div>
        </div>
    </div>
    
    <!-- Menu Cepat -->
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4">Menu Cepat</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <a href="kendaraan/masuk.php" class="bg-green-500 text-white text-center py-3 rounded hover:bg-green-600">
                🚘 Kendaraan Masuk
            </a>
            <a href="kendaraan/keluar.php" class="bg-red-500 text-white text-center py-3 rounded hover:bg-red-600">
                🚗 Kendaraan Keluar
            </a>
            <a href="transaksi/laporan.php" class="bg-blue-500 text-white text-center py-3 rounded hover:bg-blue-600">
                📊 Laporan Transaksi
            </a>
            <a href="tarif/index.php" class="bg-yellow-500 text-white text-center py-3 rounded hover:bg-yellow-600">
                💰 Kelola Tarif
            </a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>