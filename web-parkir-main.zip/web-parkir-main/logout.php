<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

if (isLogin()) {
    logAktivitas($conn, $_SESSION['user_id'], "Logout dari sistem");
    session_destroy();
}
header("Location: login.php");
exit;
?>