
function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

document.addEventListener('click', function (e) {
  if (
    e.target.classList.contains('fixed') &&
    e.target.classList.contains('bg-black/50')
  ) {
    e.target.classList.add('hidden');
  }
});

function konfirmasiHapus(url, nama) {
  if (confirm('Yakin ingin menghapus "' + nama + '"?')) {
    window.location.href = url;
  }
}

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-alert]').forEach(function (el) {
    setTimeout(function () {
      el.style.transition = 'opacity 0.5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    }, 3000);
  });
});
