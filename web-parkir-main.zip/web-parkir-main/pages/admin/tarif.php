<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Tarif Parkir';
$msg = '';

if (isset($_POST['tambah'])) {
    $jenis = mysqli_real_escape_string($conn, $_POST['jenis_kendaraan']);
    $tarif = (int)$_POST['tarif_per_jam'];
    mysqli_query($conn, "INSERT INTO tb_ukk_siswa_tarif (jenis_kendaraan, tarif_per_jam) VALUES ('$jenis', $tarif)");
    logAktivitas($conn, $_SESSION['user_id'], "Tambah tarif: $jenis");
    $msg = ['type' => 'success', 'text' => 'Tarif berhasil ditambahkan!'];
}
if (isset($_POST['edit'])) {
    $id    = (int)$_POST['id_tarif'];
    $jenis = mysqli_real_escape_string($conn, $_POST['jenis_kendaraan']);
    $tarif = (int)$_POST['tarif_per_jam'];
    mysqli_query($conn, "UPDATE tb_ukk_siswa_tarif SET jenis_kendaraan='$jenis', tarif_per_jam=$tarif WHERE id_tarif=$id");
    $msg = ['type' => 'success', 'text' => 'Tarif berhasil diperbarui!'];
}
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tb_ukk_siswa_tarif WHERE id_tarif=$id");
    $msg = ['type' => 'success', 'text' => 'Tarif berhasil dihapus!'];
}

$tarifs = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_tarif ORDER BY id_tarif");
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-money-bill mr-2"></i> Tarif Parkir</h2>
        <p class="text-slate-500 text-sm mt-1">Kelola tarif parkir per jenis kendaraan</p>
    </div>

    <?php if ($msg): ?>
    <div class="mb-5 px-4 py-3 rounded-lg text-sm font-medium border-l-4 <?= $msg['type']==='success' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-red-50 border-red-500 text-red-700' ?>">
        <?= $msg['text'] ?>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-slate-700">Daftar Tarif</h3>
            <button onclick="openModal('modalTambah')"
                    class="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
                + Tambah Tarif
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis Kendaraan</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Tarif / Jam</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no = 1; while ($t = mysqli_fetch_assoc($tarifs)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3 font-semibold"><?= ucfirst($t['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3">Rp <?= number_format($t['tarif_per_jam'], 0, ',', '.') ?></td>
                    <td class="py-3 px-3 flex gap-2">
                        <button onclick="openModal('editModal<?= $t['id_tarif'] ?>')"
                                class="bg-amber-100 hover:bg-amber-200 text-amber-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Edit</button>
                        <button onclick="konfirmasiHapus('/parking-latihan/pages/admin/tarif.php?hapus=<?= $t['id_tarif'] ?>','tarif ini')"
                                class="bg-red-100 hover:bg-red-200 text-red-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Hapus</button>
                    </td>
                </tr>

                <div id="editModal<?= $t['id_tarif'] ?>" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
                        <div class="flex justify-between items-center mb-5">
                            <h3 class="font-bold text-lg">Edit Tarif</h3>
                            <button onclick="closeModal('editModal<?= $t['id_tarif'] ?>')"
                                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="id_tarif" value="<?= $t['id_tarif'] ?>">
                            <div class="mb-4">
                                <label class="block text-sm font-semibold mb-1.5">Jenis Kendaraan</label>
                                <select name="jenis_kendaraan" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                    <option value="motor"   <?= $t['jenis_kendaraan']==='motor'   ? 'selected' : '' ?>>Motor</option>
                                    <option value="mobil"   <?= $t['jenis_kendaraan']==='mobil'   ? 'selected' : '' ?>>Mobil</option>
                                    <option value="lainnya" <?= $t['jenis_kendaraan']==='lainnya' ? 'selected' : '' ?>>Lainnya</option>
                                </select>
                            </div>
                            <div class="mb-5">
                                <label class="block text-sm font-semibold mb-1.5">Tarif per Jam (Rp)</label>
                                <input type="number" name="tarif_per_jam" value="<?= $t['tarif_per_jam'] ?>" required
                                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                            </div>
                            <button type="submit" name="edit"
                                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                                Simpan Perubahan
                            </button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="modalTambah" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div class="flex justify-between items-center mb-5">
            <h3 class="font-bold text-lg">Tambah Tarif Baru</h3>
            <button onclick="closeModal('modalTambah')"
                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
        </div>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1.5">Jenis Kendaraan</label>
                <select name="jenis_kendaraan" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                    <option value="motor">Motor</option>
                    <option value="mobil">Mobil</option>
                    <option value="lainnya">Lainnya</option>
                </select>
            </div>
            <div class="mb-5">
                <label class="block text-sm font-semibold mb-1.5">Tarif per Jam (Rp)</label>
                <input type="number" name="tarif_per_jam" required
                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none"
                       placeholder="Contoh: 2000">
            </div>
            <button type="submit" name="tambah"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                Tambah Tarif
            </button>
        </form>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>