<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Dashboard Admin';

$totalUser       = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_user"))[0];
$totalKendaraan  = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_kendaraan"))[0];
$totalArea       = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_area_parkir"))[0];
$kendaraanParkir = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE status='masuk'"))[0];
$pendapatanHari  = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(biaya_total),0) FROM tb_ukk_siswa_transaksi WHERE DATE(waktu_keluar)=CURDATE()"))[0];

$transaksi = mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area, u.nama_lengkap
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    JOIN tb_ukk_siswa_user u ON t.id_user=u.id_user
    ORDER BY t.waktu_masuk DESC LIMIT 10
");

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">

    <div class="mb-6">
        <h2 class="text-xl font-extrabold text-slate-800">Dashboard Admin</h2>
        <p class="text-slate-500 text-sm mt-1">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?>!</p>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <?php
        $stats = [
            ['<i class="fa-solid fa-user"></i>', 'bg-blue-100',   'text-green-600',   $totalUser, 'Total User'],
            ['<i class="fa-solid fa-car"></i>', 'bg-green-100',  'text-green-600',  $totalKendaraan,'Kendaraan'],
            ['<i class="fa-solid fa-square-parking"></i>', 'bg-amber-100',  'text-amber-600',  $kendaraanParkir,'Sedang Parkir'],
            ['<i class="fa-regular fa-map"></i>', 'bg-red-100',    'text-red-600',    $totalArea,'Area Parkir'],
            ['<i class="fa-solid fa-money-bill-trend-up"></i>', 'bg-emerald-100','text-emerald-600','Rp '.number_format($pendapatanHari,0,',','.'),'Pendapatan Hari Ini'],
        ];
        foreach ($stats as [$icon, $bg, $color, $val, $label]):
        ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div class="w-11 h-11 <?= $bg ?> rounded-xl flex items-center justify-center text-xl shrink-0"><?= $icon ?></div>
            <div>
                <p class="font-extrabold text-slate-800 text-base leading-tight"><?= $val ?></p>
                <p class="text-slate-500 text-xs"><?= $label ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-clock"></i> Transaksi Terbaru</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Plat</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Area</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Masuk</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Keluar</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Biaya</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase tracking-wide">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php while ($row = mysqli_fetch_assoc($transaksi)): ?>
                <tr class="hover:bg-slate-50 transition-colors">
                    <td class="py-3 px-3 font-bold"><?= htmlspecialchars($row['plat_nomor']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($row['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($row['nama_area']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= date('d/m H:i', strtotime($row['waktu_masuk'])) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= $row['waktu_keluar'] ? date('d/m H:i', strtotime($row['waktu_keluar'])) : '-' ?></td>
                    <td class="py-3 px-3">Rp <?= number_format($row['biaya_total'],0,',','.') ?></td>
                    <td class="py-3 px-3">
                        <?php if ($row['status'] === 'masuk'): ?>
                            <span class="bg-amber-100 text-amber-700 text-xs font-bold px-2.5 py-1 rounded-full">Masuk</span>
                        <?php else: ?>
                            <span class="bg-green-100 text-green-700 text-xs font-bold px-2.5 py-1 rounded-full">Keluar</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>