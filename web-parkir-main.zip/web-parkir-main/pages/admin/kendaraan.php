<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Kendaraan';
$msg = '';

if (isset($_POST['tambah'])) {
    $plat    = mysqli_real_escape_string($conn, strtoupper(trim($_POST['plat_nomor'])));
    $jenis   = mysqli_real_escape_string($conn, $_POST['jenis_kendaraan']);
    $warna   = mysqli_real_escape_string($conn, $_POST['warna']);
    $pemilik = mysqli_real_escape_string($conn, $_POST['pemilik']);
    mysqli_query($conn, "INSERT INTO tb_ukk_siswa_kendaraan (plat_nomor, jenis_kendaraan, warna, pemilik, id_user) VALUES ('$plat','$jenis','$warna','$pemilik',{$_SESSION['user_id']})");
    logAktivitas($conn, $_SESSION['user_id'], "Tambah kendaraan: $plat");
    $msg = ['type' => 'success', 'text' => 'Kendaraan berhasil ditambahkan!'];
}
if (isset($_POST['edit'])) {
    $id      = (int)$_POST['id_kendaraan'];
    $plat    = mysqli_real_escape_string($conn, strtoupper(trim($_POST['plat_nomor'])));
    $jenis   = mysqli_real_escape_string($conn, $_POST['jenis_kendaraan']);
    $warna   = mysqli_real_escape_string($conn, $_POST['warna']);
    $pemilik = mysqli_real_escape_string($conn, $_POST['pemilik']);
    mysqli_query($conn, "UPDATE tb_ukk_siswa_kendaraan SET plat_nomor='$plat', jenis_kendaraan='$jenis', warna='$warna', pemilik='$pemilik' WHERE id_kendaraan=$id");
    $msg = ['type' => 'success', 'text' => 'Kendaraan berhasil diperbarui!'];
}
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tb_ukk_siswa_kendaraan WHERE id_kendaraan=$id");
    $msg = ['type' => 'success', 'text' => 'Kendaraan berhasil dihapus!'];
}

$kendaraans = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_kendaraan ORDER BY id_kendaraan DESC");
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold">🚗 Kendaraan</h2>
        <p class="text-slate-500 text-sm mt-1">Kelola data kendaraan terdaftar</p>
    </div>

    <?php if ($msg): ?>
    <div class="mb-5 px-4 py-3 rounded-lg text-sm font-medium border-l-4 <?= $msg['type']==='success' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-red-50 border-red-500 text-red-700' ?>">
        <?= $msg['text'] ?>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-slate-700">Daftar Kendaraan</h3>
            <button onclick="openModal('modalTambah')"
                    class="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
                + Tambah Kendaraan
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Plat Nomor</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Warna</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Pemilik</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no = 1; while ($k = mysqli_fetch_assoc($kendaraans)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3">
                        <span class="font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700 tracking-wider text-xs">
                            <?= htmlspecialchars($k['plat_nomor']) ?>
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($k['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($k['warna'] ?? '') ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($k['pemilik'] ?? '') ?></td>
                    <td class="py-3 px-3 flex gap-2">
                        <button onclick="openModal('editKendaraan<?= $k['id_kendaraan'] ?>')"
                                class="bg-amber-100 hover:bg-amber-200 text-amber-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Edit</button>
                        <button onclick="konfirmasiHapus('/parking-latihan/pages/admin/kendaraan.php?hapus=<?= $k['id_kendaraan'] ?>','<?= $k['plat_nomor'] ?>')"
                                class="bg-red-100 hover:bg-red-200 text-red-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Hapus</button>
                    </td>
                </tr>

                <div id="editKendaraan<?= $k['id_kendaraan'] ?>" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
                        <div class="flex justify-between items-center mb-5">
                            <h3 class="font-bold text-lg">Edit Kendaraan</h3>
                            <button onclick="closeModal('editKendaraan<?= $k['id_kendaraan'] ?>')"
                                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="id_kendaraan" value="<?= $k['id_kendaraan'] ?>">
                            <div class="grid grid-cols-2 gap-3 mb-4">
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Plat Nomor</label>
                                    <input type="text" name="plat_nomor" value="<?= htmlspecialchars($k['plat_nomor']) ?>" required
                                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none uppercase">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Jenis</label>
                                    <input type="text" name="jenis_kendaraan" value="<?= htmlspecialchars($k['jenis_kendaraan']) ?>"
                                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3 mb-5">
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Warna</label>
                                    <input type="text" name="warna" value="<?= htmlspecialchars($k['warna']) ?>"
                                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Pemilik</label>
                                    <input type="text" name="pemilik" value="<?= htmlspecialchars($k['pemilik']) ?>"
                                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                </div>
                            </div>
                            <button type="submit" name="edit"
                                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                                Simpan Perubahan
                            </button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div id="modalTambah" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div class="flex justify-between items-center mb-5">
            <h3 class="font-bold text-lg">Tambah Kendaraan</h3>
            <button onclick="closeModal('modalTambah')"
                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
        </div>
        <form method="POST">
            <div class="grid grid-cols-2 gap-3 mb-4">
                <div>
                    <label class="block text-sm font-semibold mb-1.5">Plat Nomor</label>
                    <input type="text" name="plat_nomor" required placeholder="B 1234 AB"
                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none uppercase">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1.5">Jenis</label>
                    <input type="text" name="jenis_kendaraan" placeholder="Motor / Mobil"
                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3 mb-5">
                <div>
                    <label class="block text-sm font-semibold mb-1.5">Warna</label>
                    <input type="text" name="warna" placeholder="Merah"
                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-sm font-semibold mb-1.5">Pemilik</label>
                    <input type="text" name="pemilik" placeholder="Nama pemilik"
                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                </div>
            </div>
            <button type="submit" name="tambah"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                Tambah Kendaraan
            </button>
        </form>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>