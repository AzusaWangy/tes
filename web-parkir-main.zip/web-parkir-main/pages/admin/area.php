<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Area Parkir';
$msg = '';

if (isset($_POST['tambah'])) {
    $nama      = mysqli_real_escape_string($conn, $_POST['nama_area']);
    $kapasitas = (int)$_POST['kapasitas'];
    mysqli_query($conn, "INSERT INTO tb_ukk_siswa_area_parkir (nama_area, kapasitas, terisi) VALUES ('$nama', $kapasitas, 0)");
    logAktivitas($conn, $_SESSION['user_id'], "Tambah area: $nama");
    $msg = ['type' => 'success', 'text' => 'Area berhasil ditambahkan!'];
}
if (isset($_POST['edit'])) {
    $id        = (int)$_POST['id_area'];
    $nama      = mysqli_real_escape_string($conn, $_POST['nama_area']);
    $kapasitas = (int)$_POST['kapasitas'];
    mysqli_query($conn, "UPDATE tb_ukk_siswa_area_parkir SET nama_area='$nama', kapasitas=$kapasitas WHERE id_area=$id");
    $msg = ['type' => 'success', 'text' => 'Area berhasil diperbarui!'];
}
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tb_ukk_siswa_area_parkir WHERE id_area=$id");
    $msg = ['type' => 'success', 'text' => 'Area berhasil dihapus!'];
}

$areas = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_area_parkir ORDER BY id_area");
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-map mr-2"></i> Area Parkir</h2>
        <p class="text-slate-500 text-sm mt-1">Kelola area dan kapasitas parkir</p>
    </div>

    <?php if ($msg): ?>
    <div class="mb-5 px-4 py-3 rounded-lg text-sm font-medium border-l-4 <?= $msg['type']==='success' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-red-50 border-red-500 text-red-700' ?>">
        <?= $msg['text'] ?>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-slate-700">Daftar Area</h3>
            <button onclick="openModal('modalTambah')"
                    class="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
                + Tambah Area
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Nama Area</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Kapasitas</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Terisi</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Sisa</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no = 1; while ($a = mysqli_fetch_assoc($areas)):
                    $sisa   = $a['kapasitas'] - $a['terisi'];
                    $persen = $a['kapasitas'] > 0 ? round(($a['terisi'] / $a['kapasitas']) * 100) : 0;
                    $barColor = $persen >= 90 ? 'bg-red-500' : ($persen >= 60 ? 'bg-amber-400' : 'bg-green-500');
                ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3 font-semibold"><?= htmlspecialchars($a['nama_area']) ?></td>
                    <td class="py-3 px-3"><?= $a['kapasitas'] ?></td>
                    <td class="py-3 px-3">
                        <div class="flex items-center gap-2">
                            <div class="w-24 bg-slate-100 rounded-full h-2">
                                <div class="<?= $barColor ?> h-2 rounded-full" style="width:<?= $persen ?>%"></div>
                            </div>
                            <span class="text-xs text-slate-500"><?= $a['terisi'] ?></span>
                        </div>
                    </td>
                    <td class="py-3 px-3">
                        <span class="text-xs font-bold px-2.5 py-1 rounded-full <?= $sisa > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                            <?= $sisa ?> slot
                        </span>
                    </td>
                    <td class="py-3 px-3 flex gap-2">
                        <button onclick="openModal('editModal<?= $a['id_area'] ?>')"
                                class="bg-amber-100 hover:bg-amber-200 text-amber-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Edit</button>
                        <button onclick="konfirmasiHapus('/parking-latihan/pages/admin/area.php?hapus=<?= $a['id_area'] ?>','area ini')"
                                class="bg-red-100 hover:bg-red-200 text-red-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Hapus</button>
                    </td>
                </tr>

                <div id="editModal<?= $a['id_area'] ?>" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
                        <div class="flex justify-between items-center mb-5">
                            <h3 class="font-bold text-lg">Edit Area</h3>
                            <button onclick="closeModal('editModal<?= $a['id_area'] ?>')"
                                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="id_area" value="<?= $a['id_area'] ?>">
                            <div class="mb-4">
                                <label class="block text-sm font-semibold mb-1.5">Nama Area</label>
                                <input type="text" name="nama_area" value="<?= htmlspecialchars($a['nama_area']) ?>" required
                                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                            </div>
                            <div class="mb-5">
                                <label class="block text-sm font-semibold mb-1.5">Kapasitas</label>
                                <input type="number" name="kapasitas" value="<?= $a['kapasitas'] ?>" required
                                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                            </div>
                            <button type="submit" name="edit"
                                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                                Simpan Perubahan
                            </button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="modalTambah" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div class="flex justify-between items-center mb-5">
            <h3 class="font-bold text-lg">Tambah Area Parkir</h3>
            <button onclick="closeModal('modalTambah')"
                    class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
        </div>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1.5">Nama Area</label>
                <input type="text" name="nama_area" required
                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none"
                       placeholder="Contoh: Area A - Motor">
            </div>
            <div class="mb-5">
                <label class="block text-sm font-semibold mb-1.5">Kapasitas</label>
                <input type="number" name="kapasitas" required
                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none"
                       placeholder="Contoh: 50">
            </div>
            <button type="submit" name="tambah"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                Tambah Area
            </button>
        </form>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>