<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Log Aktivitas';

$logs = mysqli_query($conn, "
    SELECT l.*, u.nama_lengkap, u.role
    FROM tb_ukk_siswa_log_aktivitas l
    JOIN tb_ukk_siswa_user u ON l.id_user = u.id_user
    ORDER BY l.waktu_aktivitas DESC
    LIMIT 200
");

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-clipboard mr-2"></i>Log Aktivitas</h2>
        <p class="text-slate-500 text-sm mt-1">Rekam jejak aktivitas semua pengguna (200 terbaru)</p>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Waktu</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">User</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Role</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aktivitas</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no = 1; while ($l = mysqli_fetch_assoc($logs)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3 text-slate-500 whitespace-nowrap">
                        <?= date('d/m/Y H:i:s', strtotime($l['waktu_aktivitas'])) ?>
                    </td>
                    <td class="py-3 px-3 font-semibold"><?= htmlspecialchars($l['nama_lengkap']) ?></td>
                    <td class="py-3 px-3">
                        <?php
                        $roleColor = match($l['role']) {
                            'admin'   => 'bg-blue-100 text-green-700',
                            'petugas' => 'bg-amber-100 text-amber-700',
                            'owner'   => 'bg-purple-100 text-purple-700',
                            default   => 'bg-slate-100 text-slate-700'
                        };
                        ?>
                        <span class="<?= $roleColor ?> text-xs font-bold px-2.5 py-1 rounded-full">
                            <?= $l['role'] ?>
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($l['aktivitas']) ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>