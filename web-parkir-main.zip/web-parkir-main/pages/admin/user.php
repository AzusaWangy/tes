<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('admin');
$pageTitle = 'Kelola User';
$msg = '';

if (isset($_POST['tambah'])) {
    $nama     = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = MD5($_POST['password']);
    $role     = mysqli_real_escape_string($conn, $_POST['role']);
    $cek = mysqli_query($conn, "SELECT id_user FROM tb_ukk_siswa_user WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        $msg = ['type' => 'error', 'text' => 'Username sudah digunakan!'];
    } else {
        mysqli_query($conn, "INSERT INTO tb_ukk_siswa_user (nama_lengkap,username,password,role) VALUES ('$nama','$username','$password','$role')");
        logAktivitas($conn, $_SESSION['user_id'], "Tambah user: $username");
        $msg = ['type' => 'success', 'text' => 'User berhasil ditambahkan!'];
    }
}
if (isset($_POST['edit'])) {
    $id     = (int)$_POST['id_user'];
    $nama   = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $role   = mysqli_real_escape_string($conn, $_POST['role']);
    $status = (int)$_POST['status_aktif'];
    $sql    = "UPDATE tb_ukk_siswa_user SET nama_lengkap='$nama',role='$role',status_aktif=$status WHERE id_user=$id";
    if (!empty($_POST['password'])) {
        $pass = MD5($_POST['password']);
        $sql  = "UPDATE tb_ukk_siswa_user SET nama_lengkap='$nama',role='$role',status_aktif=$status,password='$pass' WHERE id_user=$id";
    }
    mysqli_query($conn, $sql);
    $msg = ['type' => 'success', 'text' => 'User berhasil diperbarui!'];
}
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    if ($id !== (int)$_SESSION['user_id']) {
        mysqli_query($conn, "DELETE FROM tb_ukk_siswa_user WHERE id_user=$id");
        $msg = ['type' => 'success', 'text' => 'User berhasil dihapus!'];
    } else {
        $msg = ['type' => 'error', 'text' => 'Tidak bisa menghapus akun sendiri!'];
    }
}

$users = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_user ORDER BY id_user");
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-user mr-2"></i> Kelola User</h2>
        <p class="text-slate-500 text-sm mt-1">Manajemen akun pengguna sistem</p>
    </div>

    <?php if ($msg): ?>
    <div class="mb-5 px-4 py-3 rounded-lg text-sm font-medium border-l-4 <?= $msg['type']==='success' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-red-50 border-red-500 text-red-700' ?>">
        <?= $msg['text'] ?>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-slate-700">Daftar User</h3>
            <button onclick="openModal('modalTambah')"
                    class="bg-green-600 hover:bg-green-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
                + Tambah User
            </button>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Nama</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Username</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Role</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Status</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no=1; while ($u = mysqli_fetch_assoc($users)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3 font-semibold"><?= htmlspecialchars($u['nama_lengkap']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($u['username']) ?></td>
                    <td class="py-3 px-3">
                        <span class="bg-blue-100 text-green-700 text-xs font-bold px-2.5 py-1 rounded-full"><?= $u['role'] ?></span>
                    </td>
                    <td class="py-3 px-3">
                        <?php if ($u['status_aktif']): ?>
                            <span class="bg-green-100 text-green-700 text-xs font-bold px-2.5 py-1 rounded-full">Aktif</span>
                        <?php else: ?>
                            <span class="bg-red-100 text-red-700 text-xs font-bold px-2.5 py-1 rounded-full">Nonaktif</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-3 flex gap-2">
                        <button onclick="openModal('editModal<?= $u['id_user'] ?>')"
                                class="bg-amber-100 hover:bg-amber-200 text-amber-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Edit</button>
                        <button onclick="konfirmasiHapus('/parking-latihan/pages/admin/user.php?hapus=<?= $u['id_user'] ?>','<?= $u['nama_lengkap'] ?>')"
                                class="bg-red-100 hover:bg-red-200 text-red-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">Hapus</button>
                    </td>
                </tr>

                <div id="editModal<?= $u['id_user'] ?>" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
                        <div class="flex justify-between items-center mb-5">
                            <h3 class="font-bold text-lg">Edit User</h3>
                            <button onclick="closeModal('editModal<?= $u['id_user'] ?>')" class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="id_user" value="<?= $u['id_user'] ?>">
                            <div class="mb-4">
                                <label class="block text-sm font-semibold mb-1.5">Nama Lengkap</label>
                                <input type="text" name="nama_lengkap" value="<?= htmlspecialchars($u['nama_lengkap']) ?>" required
                                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-semibold mb-1.5">Password Baru <span class="text-slate-400 font-normal">(kosongkan jika tidak diubah)</span></label>
                                <input type="password" name="password"
                                       class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                            </div>
                            <div class="grid grid-cols-2 gap-3 mb-5">
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Role</label>
                                    <select name="role" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                        <option value="admin" <?= $u['role']==='admin'?'selected':'' ?>>Admin</option>
                                        <option value="petugas" <?= $u['role']==='petugas'?'selected':'' ?>>Petugas</option>
                                        <option value="owner" <?= $u['role']==='owner'?'selected':'' ?>>Owner</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold mb-1.5">Status</label>
                                    <select name="status_aktif" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                                        <option value="1" <?= $u['status_aktif']?'selected':'' ?>>Aktif</option>
                                        <option value="0" <?= !$u['status_aktif']?'selected':'' ?>>Nonaktif</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" name="edit"
                                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                                Simpan Perubahan
                            </button>
                        </form>
                    </div>
                </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="modalTambah" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div class="flex justify-between items-center mb-5">
            <h3 class="font-bold text-lg">Tambah User Baru</h3>
            <button onclick="closeModal('modalTambah')" class="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center hover:bg-slate-200 transition-colors">✕</button>
        </div>
        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1.5">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" required class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1.5">Username</label>
                <input type="text" name="username" required class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-1.5">Password</label>
                <input type="password" name="password" required class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
            </div>
            <div class="mb-5">
                <label class="block text-sm font-semibold mb-1.5">Role</label>
                <select name="role" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                    <option value="admin">Admin</option>
                    <option value="petugas">Petugas</option>
                    <option value="owner">Owner</option>
                </select>
            </div>
            <button type="submit" name="tambah"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                Tambah User
            </button>
        </form>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>