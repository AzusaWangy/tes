<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('owner');
$pageTitle = 'Dashboard Owner';

$totalPendapatan = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(biaya_total),0) FROM tb_ukk_siswa_transaksi WHERE status='keluar'"))[0];
$pendapatanHari  = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(biaya_total),0) FROM tb_ukk_siswa_transaksi WHERE DATE(waktu_keluar)=CURDATE()"))[0];
$pendapatanBulan = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(biaya_total),0) FROM tb_ukk_siswa_transaksi WHERE MONTH(waktu_keluar)=MONTH(CURDATE()) AND YEAR(waktu_keluar)=YEAR(CURDATE())"))[0];
$totalTransaksi  = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE status='keluar'"))[0];

$perJenis = mysqli_query($conn, "
    SELECT k.jenis_kendaraan, COUNT(*) AS jumlah, SUM(t.biaya_total) AS total
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    WHERE t.status='keluar'
    GROUP BY k.jenis_kendaraan
");

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-chart-line mr-2"></i> Dashboard Owner</h2>
        <p class="text-slate-500 text-sm mt-1">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?>!</p>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <?php
        $stats = [
            ['<i class="fa-solid fa-money-bill-wave"></i>', 'bg-green-100',  'Rp '.number_format($pendapatanHari,0,',','.'),  'Pendapatan Hari Ini'],
            ['<i class="fa-solid fa-calendar-days"></i>',   'bg-blue-100',   'Rp '.number_format($pendapatanBulan,0,',','.'), 'Pendapatan Bulan Ini'],
            ['<i class="fa-solid fa-chart-line"></i>',      'bg-purple-100', 'Rp '.number_format($totalPendapatan,0,',','.'), 'Total Pendapatan'],
            ['<i class="fa-solid fa-receipt"></i>',         'bg-amber-100',  $totalTransaksi,                                  'Total Transaksi'],
        ];
        foreach ($stats as [$icon, $bg, $val, $label]):
        ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div class="w-11 h-11 <?= $bg ?> rounded-xl flex items-center justify-center text-xl shrink-0"><?= $icon ?></div>
            <div>
                <p class="font-extrabold text-slate-800 text-sm leading-tight"><?= $val ?></p>
                <p class="text-slate-500 text-xs"><?= $label ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5 mb-5">
        <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-calendar-days mr-2"></i>Pendapatan per Jenis Kendaraan</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jumlah Transaksi</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Total Pendapatan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php while ($r = mysqli_fetch_assoc($perJenis)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 font-semibold capitalize"><?= htmlspecialchars($r['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= $r['jumlah'] ?> transaksi</td>
                    <td class="py-3 px-3 font-bold text-green-700">Rp <?= number_format($r['total'],0,',','.') ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="rekap.php"
       class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors text-sm">
        <i class="fa-solid fa-chart-area mr-2"></i>Lihat Rekap Lengkap
    </a>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>