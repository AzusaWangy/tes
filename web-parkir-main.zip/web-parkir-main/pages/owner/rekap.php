<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('owner');
$pageTitle = 'Rekap Transaksi';

$dari   = isset($_GET['dari'])   ? $_GET['dari']   : date('Y-m-01');
$sampai = isset($_GET['sampai']) ? $_GET['sampai'] : date('Y-m-d');

$dari_safe   = mysqli_real_escape_string($conn, $dari);
$sampai_safe = mysqli_real_escape_string($conn, $sampai);

$transaksis = mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area, u.nama_lengkap
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    JOIN tb_ukk_siswa_user u ON t.id_user=u.id_user
    WHERE t.status='keluar' AND DATE(t.waktu_keluar) BETWEEN '$dari_safe' AND '$sampai_safe'
    ORDER BY t.waktu_keluar DESC
");

$summary = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total_trx, COALESCE(SUM(biaya_total),0) AS total_pendapatan
    FROM tb_ukk_siswa_transaksi
    WHERE status='keluar' AND DATE(waktu_keluar) BETWEEN '$dari_safe' AND '$sampai_safe'
"));

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-chart-area mr-2"></i> Rekap Transaksi</h2>
        <p class="text-slate-500 text-sm mt-1">Laporan pendapatan parkir berdasarkan periode</p>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-4 mb-5">
        <form method="GET" class="flex flex-wrap gap-3 items-end">
            <div>
                <label class="block text-sm font-semibold mb-1.5">Dari Tanggal</label>
                <input type="date" name="dari" value="<?= $dari ?>"
                       class="px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
            </div>
            <div>
                <label class="block text-sm font-semibold mb-1.5">Sampai Tanggal</label>
                <input type="date" name="sampai" value="<?= $sampai ?>"
                       class="px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
            </div>
            <button type="submit"
                    class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors text-sm">
                <i class="fa-solid fa-filter mr-2"></i> Filter
            </button>
            <a href="rekap.php"
               class="bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-4 py-2.5 rounded-xl transition-colors text-sm">
                <i class="fa-solid fa-sync-alt mr-2"></i> Reset
            </a>
            
            <a href="cetak.php?dari=<?= $dari ?>&sampai=<?= $sampai ?>" target="_blank"
                class="bg-red-600 hover:bg-red-700 text-white font-semibold px-4 py-2.5 rounded-xl text-sm">
                 <i class="fa-solid fa-file-pdf mr-2"></i> Cetak PDF
            </a>
        </form>
    </div>

    <div class="grid grid-cols-2 gap-4 mb-5">
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div class="w-11 h-11 bg-blue-100 rounded-xl flex items-center justify-center text-xl"><i class="fa-solid fa-receipt"></i></div>
            <div>
                <p class="font-extrabold text-slate-800 text-xl"><?= $summary['total_trx'] ?></p>
                <p class="text-slate-500 text-xs">Total Transaksi</p>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div class="w-11 h-11 bg-green-100 rounded-xl flex items-center justify-center text-xl"><i class="fa-solid fa-money-bill"></i></div>
            <div>
                <p class="font-extrabold text-slate-800 text-base">Rp <?= number_format($summary['total_pendapatan'],0,',','.') ?></p>
                <p class="text-slate-500 text-xs">Total Pendapatan</p>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h3 class="font-bold text-slate-700 mb-4">
            Detail: <?= date('d/m/Y', strtotime($dari)) ?> — <?= date('d/m/Y', strtotime($sampai)) ?>
        </h3>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">#</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Plat</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Area</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Masuk</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Keluar</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Durasi</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Biaya</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Petugas</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php $no = 1; while ($r = mysqli_fetch_assoc($transaksis)): ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3 text-slate-400"><?= $no++ ?></td>
                    <td class="py-3 px-3">
                        <span class="font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700 tracking-wider text-xs">
                            <?= htmlspecialchars($r['plat_nomor']) ?>
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['nama_area']) ?></td>
                    <td class="py-3 px-3 text-slate-600 whitespace-nowrap"><?= date('d/m H:i', strtotime($r['waktu_masuk'])) ?></td>
                    <td class="py-3 px-3 text-slate-600 whitespace-nowrap"><?= date('d/m H:i', strtotime($r['waktu_keluar'])) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= $r['durasi_jam'] ?> jam</td>
                    <td class="py-3 px-3 font-bold text-green-700">Rp <?= number_format($r['biaya_total'],0,',','.') ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['nama_lengkap']) ?></td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>