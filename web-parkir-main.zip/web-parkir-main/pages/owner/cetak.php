<?php
require_once '../../config/database.php';

$dari   = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');

$dari_safe   = mysqli_real_escape_string($conn, $dari);
$sampai_safe = mysqli_real_escape_string($conn, $sampai);

$data = mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area, u.nama_lengkap
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    JOIN tb_ukk_siswa_user u ON t.id_user=u.id_user
    WHERE t.status='keluar'
    AND DATE(t.waktu_keluar) BETWEEN '$dari_safe' AND '$sampai_safe'
    ORDER BY t.waktu_keluar DESC
");

$summary = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total_trx, COALESCE(SUM(biaya_total),0) AS total_pendapatan
    FROM tb_ukk_siswa_transaksi
    WHERE status='keluar'
    AND DATE(waktu_keluar) BETWEEN '$dari_safe' AND '$sampai_safe'
"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        h2 {
            text-align: center;
            margin-bottom: 5px;
        }
        .periode {
            text-align: center;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #000;
            padding: 6px;
        }
        th {
            background: #eee;
        }
        .right {
            text-align: right;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="no-print" style="margin-bottom:10px;">
    <button onclick="window.print()">🖨️ Print / Save PDF</button>
</div>

<h2>LAPORAN REKAP TRANSAKSI PARKIR</h2>
<div class="periode">
    Periode: <?= date('d/m/Y', strtotime($dari)) ?> - <?= date('d/m/Y', strtotime($sampai)) ?>
</div>

<hr>

<p>Total Transaksi: <b><?= $summary['total_trx'] ?></b></p>
<p>Total Pendapatan: <b>Rp <?= number_format($summary['total_pendapatan'],0,',','.') ?></b></p>

<br>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Plat</th>
            <th>Jenis</th>
            <th>Area</th>
            <th>Masuk</th>
            <th>Keluar</th>
            <th>Durasi</th>
            <th>Biaya</th>
            <th>Petugas</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; while($r = mysqli_fetch_assoc($data)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($r['plat_nomor']) ?></td>
            <td><?= htmlspecialchars($r['jenis_kendaraan']) ?></td>
            <td><?= htmlspecialchars($r['nama_area']) ?></td>
            <td><?= date('d/m H:i', strtotime($r['waktu_masuk'])) ?></td>
            <td><?= date('d/m H:i', strtotime($r['waktu_keluar'])) ?></td>
            <td><?= $r['durasi_jam'] ?> jam</td>
            <td class="right">Rp <?= number_format($r['biaya_total'],0,',','.') ?></td>
            <td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<br><br>

<p style="text-align:right;">
    <?= date('d/m/Y') ?><br><br><br><br>
    <b><?= htmlspecialchars($_SESSION['nama_lengkap'] ?? 'User') ?></b>
</p>

<script>
    // Auto buka print dialog
    window.onload = () => {
        window.print();
    }
</script>

</body>
</html>