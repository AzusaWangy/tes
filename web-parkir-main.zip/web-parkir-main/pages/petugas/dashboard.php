<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('petugas');
$pageTitle = 'Dashboard Petugas';

$masukHari      = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE DATE(waktu_masuk)=CURDATE()"))[0];
$keluarHari     = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE DATE(waktu_keluar)=CURDATE()"))[0];
$sedangParkir   = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE status='masuk'"))[0];
$pendapatanHari = mysqli_fetch_row(mysqli_query($conn, "SELECT COALESCE(SUM(biaya_total),0) FROM tb_ukk_siswa_transaksi WHERE DATE(waktu_keluar)=CURDATE()"))[0];

$transaksiAktif = mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    WHERE t.status='masuk'
    ORDER BY t.waktu_masuk DESC LIMIT 15
");

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold">Dashboard Petugas</h2>
        <p class="text-slate-500 text-sm mt-1">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?>!</p>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <?php
        $stats = [
            ['<i class="fa-solid fa-right-to-bracket"></i>', 'bg-blue-100',    $masukHari,                                              'Masuk Hari Ini'],
            ['<i class="fa-solid fa-right-from-bracket"></i>', 'bg-green-100',   $keluarHari,                                             'Keluar Hari Ini'],
            ['<i class="fa-solid fa-square-parking"></i>', 'bg-amber-100',   $sedangParkir,                                           'Sedang Parkir'],
            ['<i class="fa-solid fa-money-bill"></i>', 'bg-emerald-100', 'Rp '.number_format($pendapatanHari,0,',','.'),           'Pendapatan Hari Ini'],
        ];
        foreach ($stats as [$icon, $bg, $val, $label]):
        ?>
        <div class="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            <div class="w-11 h-11 <?= $bg ?> rounded-xl flex items-center justify-center text-xl shrink-0"><?= $icon ?></div>
            <div>
                <p class="font-extrabold text-slate-800 text-base leading-tight"><?= $val ?></p>
                <p class="text-slate-500 text-xs"><?= $label ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="mb-5">
        <a href="transaksi.php"
           class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors text-sm">
             <i class="fa-solid fa-file-invoice"></i> Buka Halaman Transaksi
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-car mr-2"></i> Kendaraan Sedang Parkir</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Plat</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Area</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Waktu Masuk</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Durasi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php while ($r = mysqli_fetch_assoc($transaksiAktif)):
                    $durasi = round((time() - strtotime($r['waktu_masuk'])) / 3600, 1);
                ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3">
                        <span class="font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700 tracking-wider text-xs">
                            <?= htmlspecialchars($r['plat_nomor']) ?>
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['nama_area']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= date('H:i', strtotime($r['waktu_masuk'])) ?></td>
                    <td class="py-3 px-3">
                        <span class="bg-amber-100 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full">
                            <?= $durasi ?> jam
                        </span>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>