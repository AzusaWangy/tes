<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('petugas');
$pageTitle = 'Transaksi Parkir';
$msg = '';

if (isset($_POST['masuk'])) {
    $plat     = mysqli_real_escape_string($conn, strtoupper(trim($_POST['plat_nomor'])));
    $jenis    = mysqli_real_escape_string($conn, $_POST['jenis_kendaraan']);
    $id_area  = (int)$_POST['id_area'];
    $id_tarif = (int)$_POST['id_tarif'];
    $id_user  = $_SESSION['user_id'];

    $area = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_area_parkir WHERE id_area=$id_area"));
    if ($area['terisi'] >= $area['kapasitas']) {
        $msg = ['type' => 'error', 'text' => 'Area parkir sudah penuh!'];
    } else {
        $cekK = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_kendaraan FROM tb_ukk_siswa_kendaraan WHERE plat_nomor='$plat' LIMIT 1"));
        if ($cekK) {
            $id_kendaraan = $cekK['id_kendaraan'];
        } else {
            mysqli_query($conn, "INSERT INTO tb_ukk_siswa_kendaraan (plat_nomor, jenis_kendaraan, id_user) VALUES ('$plat','$jenis',$id_user)");
            $id_kendaraan = mysqli_insert_id($conn);
        }
        $sudahParkir = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM tb_ukk_siswa_transaksi WHERE id_kendaraan=$id_kendaraan AND status='masuk'"))[0];
        if ($sudahParkir > 0) {
            $msg = ['type' => 'error', 'text' => 'Kendaraan ini masih tercatat parkir!'];
        } else {
            mysqli_query($conn, "INSERT INTO tb_ukk_siswa_transaksi (id_kendaraan,waktu_masuk,id_tarif,status,id_user,id_area) VALUES ($id_kendaraan,NOW(),$id_tarif,'masuk',$id_user,$id_area)");
            mysqli_query($conn, "UPDATE tb_ukk_siswa_area_parkir SET terisi=terisi+1 WHERE id_area=$id_area");
            logAktivitas($conn, $id_user, "Kendaraan masuk: $plat");
            $msg = ['type' => 'success', 'text' => "Kendaraan $plat berhasil dicatat masuk!"];
        }
    }
}

if (isset($_POST['keluar'])) {
    $id_parkir = (int)$_POST['id_parkir'];
    $trx = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT t.*, tf.tarif_per_jam FROM tb_ukk_siswa_transaksi t
        JOIN tb_ukk_siswa_tarif tf ON t.id_tarif=tf.id_tarif
        WHERE t.id_parkir=$id_parkir LIMIT 1
    "));
    if ($trx) {
        $waktu_keluar = date('Y-m-d H:i:s');
        $durasi_jam   = max(1, ceil((strtotime($waktu_keluar) - strtotime($trx['waktu_masuk'])) / 3600));
        $biaya_total  = $durasi_jam * $trx['tarif_per_jam'];
        mysqli_query($conn, "UPDATE tb_ukk_siswa_transaksi SET waktu_keluar='$waktu_keluar',durasi_jam=$durasi_jam,biaya_total=$biaya_total,status='keluar' WHERE id_parkir=$id_parkir");
        mysqli_query($conn, "UPDATE tb_ukk_siswa_area_parkir SET terisi=terisi-1 WHERE id_area={$trx['id_area']}");
        logAktivitas($conn, $_SESSION['user_id'], "Kendaraan keluar, ID transaksi: $id_parkir");
        header("Location: struk.php?id=$id_parkir");
        exit;
    }
}

$transaksiAktif = mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    WHERE t.status='masuk'
    ORDER BY t.waktu_masuk DESC
");

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="ml-60 flex-1 p-8">
    <div class="mb-6">
        <h2 class="text-xl font-extrabold"><i class="fa-solid fa-file-invoice mr-2"></i> Transaksi Parkir</h2>
        <p class="text-slate-500 text-sm mt-1">Catat kendaraan masuk dan keluar</p>
    </div>

    <?php if ($msg): ?>
    <div class="mb-5 px-4 py-3 rounded-lg text-sm font-medium border-l-4 <?= $msg['type']==='success' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-red-50 border-red-500 text-red-700' ?>">
        <?= $msg['text'] ?>
    </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
        <div class="bg-white rounded-xl shadow-sm p-5">
            <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-right-to-bracket mr-2"></i> Kendaraan Masuk</h3>
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1.5">Plat Nomor</label>
                    <input type="text" name="plat_nomor" required placeholder="B 1234 AB"
                           class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none uppercase">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1.5">Jenis Kendaraan</label>
                    <select name="jenis_kendaraan" class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                        <option value="motor">Motor</option>
                        <option value="mobil">Mobil</option>
                        <option value="lainnya">Lainnya</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold mb-1.5">Area Parkir</label>
                    <select name="id_area" required class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                        <option value="">-- Pilih Area --</option>
                        <?php
                        $areas = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_area_parkir");
                        while ($a = mysqli_fetch_assoc($areas)):
                            $sisa = $a['kapasitas'] - $a['terisi'];
                        ?>
                        <option value="<?= $a['id_area'] ?>" <?= $sisa <= 0 ? 'disabled' : '' ?>>
                            <?= htmlspecialchars($a['nama_area']) ?> (Sisa: <?= $sisa ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-5">
                    <label class="block text-sm font-semibold mb-1.5">Tarif</label>
                    <select name="id_tarif" required class="w-full px-3 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none">
                        <option value="">-- Pilih Tarif --</option>
                        <?php
                        $tarifs = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_tarif");
                        while ($t = mysqli_fetch_assoc($tarifs)):
                        ?>
                        <option value="<?= $t['id_tarif'] ?>">
                            <?= ucfirst($t['jenis_kendaraan']) ?> — Rp <?= number_format($t['tarif_per_jam'],0,',','.') ?>/jam
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit" name="masuk"
                        class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">
                     <i class="fa-solid fa-plus mr-2"></i> Catat Masuk
                </button>
            </form>
        </div>

        <div class="bg-white rounded-xl shadow-sm p-5">
            <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-chart-bar mr-2"></i> Status Area Parkir</h3>
            <?php
            $areas_stat = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_area_parkir");
            while ($a = mysqli_fetch_assoc($areas_stat)):
                $persen   = $a['kapasitas'] > 0 ? round(($a['terisi'] / $a['kapasitas']) * 100) : 0;
                $barColor = $persen >= 90 ? 'bg-red-500' : ($persen >= 60 ? 'bg-amber-400' : 'bg-green-500');
            ?>
            <div class="mb-4">
                <div class="flex justify-between mb-1.5">
                    <span class="text-sm font-semibold text-slate-700"><?= htmlspecialchars($a['nama_area']) ?></span>
                    <span class="text-xs text-slate-500"><?= $a['terisi'] ?>/<?= $a['kapasitas'] ?> terisi</span>
                </div>
                <div class="w-full bg-slate-100 rounded-full h-2.5">
                    <div class="<?= $barColor ?> h-2.5 rounded-full transition-all" style="width:<?= $persen ?>%"></div>
                </div>
                <p class="text-xs text-slate-400 mt-1"><?= $persen ?>% penuh</p>
            </div>
            <?php endwhile; ?>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm p-5">
        <h3 class="font-bold text-slate-700 mb-4"><i class="fa-solid fa-car mr-2"></i> Kendaraan Sedang Parkir</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b-2 border-slate-100">
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Plat</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Jenis</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Area</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Waktu Masuk</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Durasi</th>
                        <th class="text-left py-2 px-3 text-xs font-bold text-slate-400 uppercase">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-50">
                <?php while ($r = mysqli_fetch_assoc($transaksiAktif)):
                    $durasi = round((time() - strtotime($r['waktu_masuk'])) / 3600, 1);
                ?>
                <tr class="hover:bg-slate-50">
                    <td class="py-3 px-3">
                        <span class="font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700 tracking-wider text-xs">
                            <?= htmlspecialchars($r['plat_nomor']) ?>
                        </span>
                    </td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['jenis_kendaraan']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= htmlspecialchars($r['nama_area']) ?></td>
                    <td class="py-3 px-3 text-slate-600"><?= date('d/m H:i', strtotime($r['waktu_masuk'])) ?></td>
                    <td class="py-3 px-3">
                        <span class="bg-amber-100 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full"><?= $durasi ?> jam</span>
                    </td>
                    <td class="py-3 px-3">
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="id_parkir" value="<?= $r['id_parkir'] ?>">
                            <button type="submit" name="keluar"
                                    onclick="return confirm('Proses kendaraan <?= $r['plat_nomor'] ?> keluar?')"
                                    class="bg-red-500 hover:bg-red-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">
                                ⬆️ Keluarkan
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="/parking-latihan/assets/js/main.js"></script>
</body></html>