<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';
cekRole('petugas');

$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$trx = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT t.*, k.plat_nomor, k.jenis_kendaraan, k.warna, k.pemilik,
           a.nama_area, tf.tarif_per_jam, u.nama_lengkap AS nama_petugas
    FROM tb_ukk_siswa_transaksi t
    JOIN tb_ukk_siswa_kendaraan k ON t.id_kendaraan=k.id_kendaraan
    JOIN tb_ukk_siswa_area_parkir a ON t.id_area=a.id_area
    JOIN tb_ukk_siswa_tarif tf ON t.id_tarif=tf.id_tarif
    JOIN tb_ukk_siswa_user u ON t.id_user=u.id_user
    WHERE t.id_parkir=$id LIMIT 1
"));

if (!$trx) { echo "Transaksi tidak ditemukan."; exit; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Parkir - ParkiRKU</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
        }
    </style>
</head>
<body class="bg-slate-100 min-h-screen">

    <div class="no-print p-8">
        <h2 class="text-xl font-extrabold mb-4">Struk Parkir</h2>
        <div class="flex gap-3 mb-6">
            <button onclick="window.print()"
                    class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors text-sm">
                 Cetak Struk
            </button>
            <a href="transaksi.php"
               class="inline-flex items-center gap-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold px-5 py-2.5 rounded-xl transition-colors text-sm">
                ← Kembali
            </a>
        </div>
    </div>

    <div class="max-w-xs mx-auto bg-white rounded-xl shadow-sm p-6 font-mono text-sm border border-dashed border-slate-300">
        <div class="text-center mb-3">
            <p class="text-xl font-extrabold tracking-tight">PARKIR<span class="text-green-600">KU</span></p>
            <p class="text-xs text-slate-500">Sistem Manajemen Parkir</p>
        </div>
        <div class="border-t border-dashed border-slate-300 my-3"></div>

        <div class="space-y-1 text-xs">
            <div class="flex justify-between"><span class="text-slate-500">No. Transaksi</span><span class="font-bold">#<?= str_pad($trx['id_parkir'],6,'0',STR_PAD_LEFT) ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">Plat Nomor</span><span class="font-bold"><?= htmlspecialchars($trx['plat_nomor']) ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">Jenis</span><span><?= htmlspecialchars($trx['jenis_kendaraan']) ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">Area</span><span><?= htmlspecialchars($trx['nama_area']) ?></span></div>
        </div>

        <div class="border-t border-dashed border-slate-300 my-3"></div>

        <div class="space-y-1 text-xs">
            <div class="flex justify-between"><span class="text-slate-500">Waktu Masuk</span><span><?= date('d/m/Y H:i', strtotime($trx['waktu_masuk'])) ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">Waktu Keluar</span><span><?= date('d/m/Y H:i', strtotime($trx['waktu_keluar'])) ?></span></div>
            <div class="flex justify-between"><span class="text-slate-500">Durasi</span><span><?= $trx['durasi_jam'] ?> jam</span></div>
            <div class="flex justify-between"><span class="text-slate-500">Tarif/Jam</span><span>Rp <?= number_format($trx['tarif_per_jam'],0,',','.') ?></span></div>
        </div>

        <div class="border-t border-dashed border-slate-300 my-3"></div>

        <div class="flex justify-between font-bold text-base">
            <span>TOTAL BAYAR</span>
            <span class="text-green-600">Rp <?= number_format($trx['biaya_total'],0,',','.') ?></span>
        </div>

        <div class="border-t border-dashed border-slate-300 my-3"></div>

        <div class="text-center text-xs text-slate-400">
            <p>Petugas: <?= htmlspecialchars($trx['nama_petugas']) ?></p>
            <p class="mt-1">Terima kasih! 🙏</p>
        </div>
    </div>

</body>
</html>