<?php
require_once 'includes/auth.php';
require_once 'config/database.php';

if (isLogin()) { header("Location: index.php"); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = MD5($_POST['password']);
    $result   = mysqli_query($conn, "SELECT * FROM tb_ukk_siswa_user WHERE username='$username' AND password='$password' AND status_aktif=1 LIMIT 1");

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id']  = $user['id_user'];
        $_SESSION['nama']     = $user['nama_lengkap'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        logAktivitas($conn, $user['id_user'], "Login ke sistem");
        header("Location: index.php"); exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ParkiRKU</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Plus Jakarta Sans', sans-serif; } </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-900 to-green-900 flex items-center justify-center p-4">
    <div class="w-full max-w-sm">
        <div class="bg-white rounded-2xl shadow-2xl p-8">
            <div class="text-center mb-8">
                <h1 class="text-2xl font-extrabold tracking-tight">PARKIR<span class="text-green-600">KU</span></h1>
                <p class="text-slate-500 text-sm mt-1">Sistem Manajemen Parkir</p>
            </div>

            <?php if ($error): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 text-sm px-4 py-3 rounded-lg mb-5">
                <?= $error ?>
            </div>
            <?php endif; ?>

            <?php if (isset($_GET['error']) && $_GET['error'] === 'akses'): ?>
            <div class="bg-red-50 border-l-4 border-red-500 text-red-700 text-sm px-4 py-3 rounded-lg mb-5">
                Anda tidak memiliki akses ke halaman tersebut.
            </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-slate-700 mb-1.5">Username</label>
                    <input type="text" name="username" required autofocus
                           class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none transition-colors"
                           placeholder="Masukkan username">
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-semibold text-slate-700 mb-1.5">Password</label>
                    <input type="password" name="password" required
                           class="w-full px-4 py-2.5 border-2 border-slate-200 rounded-xl text-sm focus:border-green-500 focus:outline-none transition-colors"
                           placeholder="Masukkan password">
                </div>
                <button type="submit"
                        class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl transition-colors text-sm">
                    Masuk
                </button>
            </form>

            <p class="text-center text-xs text-slate-400 mt-5">
                Demo: admin/admin123 · petugas1/petugas123 · owner/owner123
            </p>
        </div>
    </div>
</body>
</html>