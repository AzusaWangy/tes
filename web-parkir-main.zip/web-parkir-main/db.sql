-- Buat database
CREATE DATABASE IF NOT EXISTS abydanuprasetyo_lsp_smkn1mejayan_sch_id;
USE abydanuprasetyo_lsp_smkn1mejayan_sch_id;

-- Tabel User
CREATE TABLE user (
    id_user INT(11) AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(50) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin','petugas','owner') NOT NULL,
    status_aktif TINYINT(1) DEFAULT 1
);

-- Tabel Area Parkir
CREATE TABLE area_parkir (
    id_area INT(11) AUTO_INCREMENT PRIMARY KEY,
    nama_area VARCHAR(50) NOT NULL,
    kapasitas INT(5) NOT NULL,
    terisi INT(5) DEFAULT 0
);

-- Tabel Tarif
CREATE TABLE tarif (
    id_tarif INT(11) AUTO_INCREMENT PRIMARY KEY,
    jenis_kendaraan ENUM('motor','mobil','lainnya') NOT NULL,
    tarif_per_jam DECIMAL(10,0) NOT NULL
);

-- Tabel Kendaraan
CREATE TABLE kendaraan (
    id_kendaraan INT(11) AUTO_INCREMENT PRIMARY KEY,
    plat_nomor VARCHAR(15) NOT NULL,
    jenis_kendaraan VARCHAR(20) NOT NULL,
    warna VARCHAR(20),
    pemilik VARCHAR(100),
    id_user INT(11),
    FOREIGN KEY (id_user) REFERENCES user(id_user)
);

-- Tabel Transaksi
CREATE TABLE transaksi (
    id_parkir INT(11) AUTO_INCREMENT PRIMARY KEY,
    id_kendaraan INT(11) NOT NULL,
    waktu_masuk DATETIME NOT NULL,
    waktu_keluar DATETIME DEFAULT NULL,
    id_tarif INT(11) NOT NULL,
    durasi_jam INT(5) DEFAULT 0,
    biaya_total DECIMAL(10,0) DEFAULT 0,
    status ENUM('masuk','keluar') DEFAULT 'masuk',
    id_user INT(11) NOT NULL,
    id_area INT(11) NOT NULL,
    FOREIGN KEY (id_kendaraan) REFERENCES kendaraan(id_kendaraan),
    FOREIGN KEY (id_tarif) REFERENCES tarif(id_tarif),
    FOREIGN KEY (id_user) REFERENCES user(id_user),
    FOREIGN KEY (id_area) REFERENCES area_parkir(id_area)
);

-- Tabel Log Aktivitas
CREATE TABLE log_aktivitas (
    id_log INT(11) AUTO_INCREMENT PRIMARY KEY,
    id_user INT(11) NOT NULL,
    aktivitas VARCHAR(100) NOT NULL,
    waktu_aktivitas DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES user(id_user)
);

-- Data awal: user
INSERT INTO user (nama_lengkap, username, password, role) VALUES
('Administrator', 'admin', MD5('admin123'), 'admin'),
('Petugas Satu', 'petugas1', MD5('petugas123'), 'petugas'),
('Owner', 'owner', MD5('owner123'), 'owner');

-- Data awal: tarif
INSERT INTO tarif (jenis_kendaraan, tarif_per_jam) VALUES
('motor', 2000),
('mobil', 5000),
('lainnya', 3000);

-- Data awal: area parkir
INSERT INTO area_parkir (nama_area, kapasitas, terisi) VALUES
('Area A - Motor', 50, 0),
('Area B - Mobil', 30, 0),
('Area C - Umum', 20, 0);