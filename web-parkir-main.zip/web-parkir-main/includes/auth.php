<?php
session_start();

function isLogin() {
    return isset($_SESSION['user_id']);
}

function cekRole($role) {
    if (!isLogin()) {
        header("Location: /parking-latihan/login.php");
        exit;
    }
    if ($_SESSION['role'] !== $role) {
        header("Location: /parking-latihan/login.php?error=akses");
        exit;
    }
}

function cekLogin() {
    if (!isLogin()) {
        header("Location: /parking-latihan/login.php");
        exit;
    }
}

function logAktivitas($conn, $id_user, $aktivitas) {
    $aktivitas = mysqli_real_escape_string($conn, $aktivitas);
    $query = "INSERT INTO tb_ukk_siswa_log_aktivitas (id_user, aktivitas) VALUES ($id_user, '$aktivitas')";
    mysqli_query($conn, $query);
}
?>