<?php
$role = $_SESSION['role'];
$nama = $_SESSION['nama'];
$current = basename($_SERVER['PHP_SELF']);

function navLink($href, $icon, $label, $current, $file) {
    $active = $current === $file
        ? 'bg-green-600 text-white'
        : 'text-slate-400 hover:bg-slate-700 hover:text-white';
    echo "<a href='$href' class='flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all $active'>
            <span>$icon</span> $label
          </a>";
}
?>
<aside class="w-60 bg-slate-900 flex flex-col fixed h-screen top-0 left-0 overflow-y-auto z-10">

    <div class="flex items-center gap-2 px-5 py-5 border-b border-slate-700">
        <span class="text-white font-extrabold text-lg tracking-tight">PARKIR<span class="text-green-400">KU</span></span>
    </div>

    <div class="flex items-center gap-3 px-5 py-4 border-b border-slate-700">
        <div class="w-9 h-9 rounded-full bg-green-600 flex items-center justify-center text-white font-bold text-sm shrink-0">
            <?= strtoupper(substr($nama, 0, 1)) ?>
        </div>
        <div>
            <p class="text-white text-sm font-semibold leading-tight"><?= htmlspecialchars($nama) ?></p>
            <p class="text-slate-400 text-xs"><?= ucfirst($role) ?></p>
        </div>
    </div>

    <nav class="flex-1 px-3 py-4 space-y-1">
        <?php if ($role === 'admin'): ?>
            <?php navLink('/parking-latihan/pages/admin/dashboard.php', '<i class="fa-solid fa-house"></i>', 'Dashboard', $current, 'dashboard.php') ?>
            <?php navLink('/parking-latihan/pages/admin/user.php', '<i class="fa-solid fa-user"></i>', 'Kelola User', $current, 'user.php') ?>
            <?php navLink('/parking-latihan/pages/admin/tarif.php', '<i class="fa-solid fa-money-bill"></i>', 'Tarif Parkir', $current, 'tarif.php') ?>
            <?php navLink('/parking-latihan/pages/admin/area.php', '<i class="fa-solid fa-map"></i>', 'Area Parkir', $current, 'area.php') ?>
            <?php navLink('/parking-latihan/pages/admin/kendaraan.php', '<i class="fa-solid fa-car"></i>', 'Kendaraan', $current, 'kendaraan.php') ?>
            <?php navLink('/parking-latihan/pages/admin/log.php', '<i class="fa-solid fa-clipboard-list"></i>', 'Log Aktivitas', $current, 'log.php') ?>
        <?php elseif ($role === 'petugas'): ?>
            <?php navLink('/parking-latihan/pages/petugas/dashboard.php', '<i class="fa-solid fa-house"></i>', 'Dashboard', $current, 'dashboard.php') ?>
            <?php navLink('/parking-latihan/pages/petugas/transaksi.php', '<i class="fa-solid fa-money-bill"></i>', 'Transaksi', $current, 'transaksi.php') ?>
        <?php elseif ($role === 'owner'): ?>
            <?php navLink('/parking-latihan/pages/owner/dashboard.php', '<i class="fa-solid fa-house"></i>', 'Dashboard', $current, 'dashboard.php') ?>
            <?php navLink('/parking-latihan/pages/owner/rekap.php', '<i class="fa-solid fa-chart-area"></i>', 'Rekap Transaksi', $current, 'rekap.php') ?>
        <?php endif; ?>
    </nav>

    <a href="/parking-latihan/logout.php"
       class="flex items-center gap-3 px-5 py-4 text-red-400 hover:bg-red-900/20 text-sm font-semibold border-t border-slate-700 transition-all">
        Logout
    </a>
</aside>