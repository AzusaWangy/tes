<?php
require_once 'includes/auth.php';
cekLogin();

switch ($_SESSION['role']) {
    case 'admin':
        header("Location: pages/admin/dashboard.php");
        break;
    case 'petugas':
        header("Location: pages/petugas/dashboard.php");
        break;
    case 'owner':
        header("Location: pages/owner/dashboard.php");
        break;
    default:
        session_destroy();
        header("Location: login.php");
}
exit;
?>